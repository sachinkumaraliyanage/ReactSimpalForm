'use strict';

import React from 'react';
import {render} from 'react-dom';


import AppContainer from './AppContainer';


render(<AppContainer/>, document.getElementById('app'));